/**
 * 
 */
package edu.mit.ll.d4m.db.cloud;

/**
 * @author cyee
 *
 */
public class D4mException extends Exception {

	/**
	 * 
	 */
	public D4mException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public D4mException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cause
	 */
	public D4mException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 */
	public D4mException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
